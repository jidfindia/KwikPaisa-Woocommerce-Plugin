<?php
/*
* Plugin Name: KwikPaisa NEO Bank
* Plugin URI: https://www.kwikpaisa.com
* Description: Payment gateway plugin by KwikPaisa for Woocommerce sites
* Version: 1.3
* Author: KwikPaisa Dev - Jangras, Inc
* Author URI: https://www.jidf.co.in
* WC requires at least: 4.9
* WC tested up to: 5.7.1
*/
 
// Include our Gateway Class and register Payment Gateway with WooCommerce
add_action( 'plugins_loaded', 'woocommerce_kwikpaisa_init', 0 );
add_filter( 'plugin_action_links_' . plugin_basename(__FILE__), 'kwikpaisa_action_links' );

function kwikpaisa_action_links( $links ) {
   $links[] = '<a href="'. esc_url( get_admin_url(null, 'admin.php?page=wc-settings&tab=checkout') ) .'">Setup</a>';
   return $links;
}

function woocommerce_kwikpaisa_init() {
  // If the parent WC_Payment_Gateway class doesn't exist
  // it means WooCommerce is not installed on the site
  // so do nothing
  if ( ! class_exists( 'WC_Payment_Gateway' ) ) return; 
   
  // If we made it this far, then include our Gateway Class
  class WC_Gateway_kwikpaisa extends WC_Payment_Gateway {
    
    // Setup our Gateway's id, description and other values
    function __construct() {
      global $woocommerce;
      global $wpdb;
      $this->id = "kwikpaisa";
	  $this->order_button_text = __( 'Proceed to KwikPaisa', 'wc_gateway_kwikpaisa' );
      $this->icon = 'https://www.kwikpaisa.com/assets/img/black-logo.png';
      $this->method_title = __( "KwikPaisa", 'wc_gateway_kwikpaisa' );
      $this->method_description = "KwikPaisa payment gateway redirects customers to checkout page to fill in their payment details and complete the payment";
      $this->title = __( "KwikPaisa", 'wc_gateway_kwikpaisa' ); 
      $this->has_fields = false;
      $this->init_form_fields();
      $this->init_settings();     
      $this->environment         = $this->settings['environment'];
      $this->app_id     = $this->settings['app_id'];
      $this->secret_key     = $this->settings['secret_key'];
      $this->description    = $this->settings['description'];
      $this->title = $this->settings['title'];

      add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
	  add_action( 'woocommerce_api_' . strtolower( get_class( $this ) ), array( $this, 'check_kwikpaisa_response' ) );		
		
      //if ( isset( $_GET['kwikpaisa_callback'])) {		  
		//       $this->check_kwikpaisa_response();
      //  }
    }
  
  
  // Build the administration fields for this specific Gateway
    public function init_form_fields() {
      $this->form_fields = array(
                'enabled' => array(
                    'title'         => __('Enable/Disable', 'wc_gateway_kwikpaisa'),
                    'type'             => 'checkbox',
                    'label'         => __('Enable KwikPaisa payment gateway.', 'wc_gateway_kwikpaisa'),
                    'default'         => 'no',
                    'description'     => 'Show in the Payment List as a payment option'
                ),
                  'title' => array(
                    'title'         => __('Title:', 'wc_gateway_kwikpaisa'),
                    'type'            => 'text',
                    'default'         => __('KwikPaisa', 'wc_gateway_kwikpaisa'),
                    'description'     => __('This controls the title which the user sees during checkout.', 'wc_gateway_kwikpaisa'),
                    'desc_tip'         => true
                ),
                'description' => array(
                    'title'         => __('Description:', 'wc_gateway_kwikpaisa'),
                    'type'             => 'textarea',
                    'default'         => __("Pay securely via Card/Net Banking/Wallet via KwikPaisa."),
                    'description'     => __('This controls the description which the user sees during checkout.', 'wc_gateway_kwikpaisa'),
                    'desc_tip'         => true
                ),
                'environment' => array (
                    'type' => 'select',
                    'options' => array (
                        'sandbox' => __ ( 'Test Mode', 'wc_gateway_kwikpaisa' ),
                        'production' => __ ( 'Live Mode', 'wc_gateway_kwikpaisa' ) 
                    ),
                    'default' => 'sandbox',
                    'title' => __ ( 'Active Environment', 'wc_gateway_kwikpaisa' ),
                    'class' => array (
                        'wc_gateway_kwikpaisa-active-environment' 
                    ),
                    'tool_tip' => true,
                    'description' => __ ( 'You can enable Test mode or Live mode with this setting. When testing the plugin, enable Test mode and you can run test transactions using your KwikPaisa account.
                      When you are ready to go live, enable Live mode.', 'wc_gateway_kwikpaisa' ) 
                ),
                'app_id' => array(
                    'title'         => __('MID Key', 'wc_gateway_kwikpaisa'),
                    'type'             => 'text',
                    'description'     => __('Copy from your dashboard or contact KwikPaisa Team', 'wc_gateway_kwikpaisa'),
                    'desc_tip'         => true
                ),
                'secret_key' => array(
                    'title'         => __('MID Secret Key', 'wc_gateway_kwikpaisa'),
                    'type'             => 'password',
                    'description'     => __('Copy from your dashboard or contact KwikPaisa Team', 'wc_gateway_kwikpaisa'),
                    'desc_tip'         => true
                ),                
            );
    }

    function check_kwikpaisa_response(){
       global $woocommerce, $wpdb;
	
		  
		
      if($_GET['wc-api']== get_class( $this )){
        $orderId = sanitize_text_field($_POST["midorderid"]);
		list($order_id) = explode('_', $orderId);	  
        $order = new WC_Order($order_id);
		  $act = sanitize_text_field($_REQUEST["act"]);
		 if ($act == 'ret' ) {
			 $txStatus = sanitize_text_field($_POST["txn_status"]);
			 $txMsg = sanitize_text_field($_POST["txn_status"]);
			 if ($txStatus == 'SUCCESS') {
				 
				 
		if ($order && $order->get_status() == "pending") {
			
         $kwikpaisa_response = array();
          $kwikpaisa_response["midorderid"] = $orderId;
          $kwikpaisa_response["txn_amount"] = sanitize_text_field($_POST["txn_amount"]);
          $kwikpaisa_response["txn_status"] = sanitize_text_field($_POST["txn_status"]);
          $kwikpaisa_response["txn_id"] = sanitize_text_field($_POST["txn_id"]);
          $kwikpaisa_response["txn_time"] = sanitize_text_field($_POST["txn_time"]);
          $kwikpaisa_response["txn_status"] = sanitize_text_field($_POST["txn_status"]);
          $kwikpaisa_response["mode"] = sanitize_text_field($_POST["mode"]);
		   // if ($kwikpaisa_response["txn_status"] == 'SUCCESS') {
          if ($txStatus == 'SUCCESS') {
            $order -> payment_complete();
            $order -> set_transaction_id($kwikpaisa_response["txn_id"]);
            $order -> add_order_note('KwikPaisa payment successful. Payment id ' . $kwikpaisa_response["txn_id"]);
            $order -> add_order_note($kwikpaisa_response["txn_status"]);
            $woocommerce -> cart -> empty_cart();
            $this->msg['message'] = "Thank you for shopping with us. Your payment has been confirmed. KwikPaisa payment id is: <b>".$kwikpaisa_response["txn_id"]."</b>.";
            $this->msg['class'] = 'woocommerce-message';      
          } else if ($kwikpaisa_response["txn_status"] == "CANCELLED") {
            $order->update_status( 'failed', __( 'Payment has been cancelled.', 'woocommerce' ));
            $this->msg['class'] = 'woocommerce-error';
            $this->msg['message'] = "Your transaction has been cancelled. Please try again.";
            wp_safe_redirect( wc_get_cart_url() ); 
          } else if ($kwikpaisa_response["txn_status"] == "PENDING") {
            $order->update_status( 'failed', __( 'Payment is under review.', 'woocommerce' ));
            $this->msg['class'] = 'woocommerce-error';
            $this->msg['message'] = "Your transaction is under review. Please wait for an status update.";
            wp_safe_redirect( wc_get_cart_url() ); 
          } else {
            $order->update_status( 'failed', __( 'Payment Failed', 'woocommerce' ));
            $this->msg['class'] = 'woocommerce-error';
            $this->msg['message'] = "Your transaction has failed.";
            wp_safe_redirect( wc_get_cart_url() ); 
          }
          if ($showContent) {
                add_action('the_content', array(&$this, 'showMessage'));
          } 

       
        }  
				 
				 wp_safe_redirect($this->get_return_url( $order));
			 }
			 else {
		       wc_add_notice( __( 'Gateway request failed - '.$txMsg, 'woocommerce' ) ,'error');	
			   wp_safe_redirect( wc_get_checkout_url() );	 
			 }
			exit;		   
		 }

      }
    }

   public function getEnvironment()
  {
    $environment = $this->get_option( 'environment' ) === 'sandbox' ? 'sandbox' : 'production';
    return $environment;
  }
   
    function showMessage ($content) {
       return '<div class="woocommerce"><div class="'.$this->msg['class'].'">'.$this->msg['message'].'</div></div>'.$content;
    }

    // Submit payment and handle response
    public function process_payment( $order_id ) {              
		$order          = wc_get_order( $order_id );		        
        $first_name = $order->get_billing_first_name();
        $last_name = $order->get_billing_last_name();
        $phone_number = $order->get_billing_phone();
        $customerName = $first_name." ".$last_name;
        $customerEmail = $order->get_billing_email();
        $customerPhone = $phone_number;
		
		$this->notify_url  = add_query_arg( 'wc-api', get_class( $this ), home_url('/') );
		$this->return_url = add_query_arg(array('act' => "ret"), $this->notify_url);
		$this->notify_url = add_query_arg(array('act' => "callback"), $this->notify_url);
		
		if ( $this->getEnvironment() === 'sandbox' ) {
			$KP_ENV = 'TEST';
          $apiEndpoint = "https://pispp.kwikpaisa.com";
        } elseif ($this->getEnvironment() === 'production') {
			$KP_ENV = 'LIVE';
          $apiEndpoint = "https://pispp.kwikpaisa.com";
        }
		//KwikPaisa Customer Creation
        $kp_request_create_customer = array();
        $kp_request_create_customer["KP_ENVIRONMENT"] =  $KP_ENV;
        $kp_request_create_customer["KPMID"] =  $this->app_id;
        $kp_request_create_customer["KPMIDKEY"] = $this->secret_key;
        $kp_request_create_customer["CUST_NAME"] = $customerName;  
        $kp_request_create_customer["CUST_EMAIL"] = $customerEmail;  
        $kp_request_create_customer["CUST_MOBILE"] = $customerPhone; 
        $kp_request_create_customer["CUST_ADDRESS_LINE1"] = $order->get_billing_address_1();
        $kp_request_create_customer["CUST_ADDRESS_LINE2"] = $order->get_billing_address_2();
        $kp_request_create_customer["CUST_ADDRESS_CITY"] = $order->get_billing_city();
        $kp_request_create_customer["CUST_ADDRESS_STATE"] = $order->get_billing_state();
        $kp_request_create_customer["CUST_ADDRESS_COUNTRY"] = $order->get_billing_country();
        $kp_request_create_customer["CUST_ADDRESS_POSTAL_CODE"] = $order->get_billing_postcode();
        $timeout = 30;                
        $apiEndpointCustCreation="https://pispp.kwikpaisa.com/API/v1/CreateCustomer";
        $postBodyCustomerMetaData = array("body" => $kp_request_create_customer, "timeout" => $timeout);
        $kp_request_create_customer_result = wp_remote_retrieve_body(wp_remote_post(esc_url($apiEndpointCustCreation),$postBodyCustomerMetaData));
        $jsonResponseCustCreationAPI = json_decode(($kp_request_create_customer_result),true);
		$jsonResponseCustCreationAPI["status"];
        if ($jsonResponseCustCreationAPI["status"] == "success") {
			$CustIDValue=$jsonResponseCustCreationAPI["CUST_KP_ID"];
        } else {
			$errrocode=$jsonResponseCustCreationAPI["error_code"];
			$error_description=$jsonResponseCustCreationAPI["error_description"];
        wc_add_notice( __("KwikPaisa Gateway Error Code is $errrocode with msg $error_description", 'woocommerce' ) ,'error');	
          return array('result' => 'failed');
        }
		
		/// Create Payment Order Now
        $kp_request_payorder = array();
        $kp_request_payorder["KP_ENVIRONMENT"] =  $KP_ENV;
        $kp_request_payorder["KPMID"] =  $this->app_id;
        $kp_request_payorder["KPMIDKEY"] = $this->secret_key;
        $kp_request_payorder["TXN_CURRENCY"] = $order->get_currency();
        $kp_request_payorder["TXN_AMOUNT"] = $order->get_total();
        $kp_request_payorder["ORDER_ID"] = $order_id.'_'.time(); 
        $kp_request_payorder["CUST_KP_ID"] = $jsonResponseCustCreationAPI["CUST_KP_ID"]; 
        $timeout = 30;                
        $apiEndpointPayorder = "https://pispp.kwikpaisa.com/API/v1/Order";
        $postBodyPayOrderData = array("body" => $kp_request_payorder, "timeout" => $timeout);
        $kp_request_payorder_result = wp_remote_retrieve_body(wp_remote_post(esc_url($apiEndpointPayorder),$postBodyPayOrderData));
        $jsonResponsePayorderAPI = json_decode(($kp_request_payorder_result),true);
	    $jsonResponsePayorderAPI["status"];
        if ($jsonResponsePayorderAPI["status"] == "success") {
		$KP_Txn_OrderID=$jsonResponsePayorderAPI["KP_Txn_OrderID"];
		$KP_Txn_Signature=$jsonResponsePayorderAPI["KP_Txn_Signature"];
		$KP_Txn_Token=$jsonResponsePayorderAPI["KP_Txn_Token"];
        } else {
		$errrocode=$jsonResponsePayorderAPI["error_code"];
		$error_description=$jsonResponsePayorderAPI["error_description"];
wc_add_notice( __("KwikPaisa Gateway Error Code is $errrocode with msg $error_description", 'woocommerce' ) ,'error');
        return array('result' => 'failed');
       }
			
	$kwikpaisa_request_link                    = array();
    $kwikpaisa_request_link['KPMID']            = $this->app_id;
    $kwikpaisa_request_link['CUST_KP_ID']          = $jsonResponseCustCreationAPI["CUST_KP_ID"]; 
    $kwikpaisa_request_link['KP_Txn_OrderID']      = $jsonResponsePayorderAPI["KP_Txn_OrderID"];
    $kwikpaisa_request_link['KP_Txn_Signature']    = $jsonResponsePayorderAPI["KP_Txn_Signature"];
    $kwikpaisa_request_link['KP_Txn_Token']        = $jsonResponsePayorderAPI["KP_Txn_Token"];
    $kwikpaisa_request_link['KP_Return_URL']        = $this->return_url;
    $kwikpaisa_request_link['source']           = "WooCommerce";
	$timeout = 30;   
	
        $apiEndpointPayorderSource = "https://pispp.kwikpaisa.com/API/v1/SourceOrder";
        $postBodyPayOrderDataSource = array("body" => $kwikpaisa_request_link, "timeout" => $timeout);
        $kp_request_payorder_resultSource = wp_remote_retrieve_body(wp_remote_post(esc_url($apiEndpointPayorderSource),$postBodyPayOrderDataSource));

        $jsonResponsePayorderAPISource = json_decode(($kp_request_payorder_resultSource),true);
	    $jsonResponsePayorderAPISource["status"];
        if ($jsonResponsePayorderAPISource["status"] == "success") {
		$SourceOrderChargeCheckOurURL=$jsonResponsePayorderAPISource["app_source_link"];
		return array('result' => 'success', 'redirect' => $SourceOrderChargeCheckOurURL);
        } else {
		$errrocode=$jsonResponsePayorderAPISource["error_code"];
		$error_description=$jsonResponsePayorderAPISource["error_description"];
        wc_add_notice( __("KwikPaisa Gateway Error Code is $errrocode with msg $error_description", 'woocommerce' ) ,'error');
        return array('result' => 'failed');
       }
        exit;
    }
  }
  
  add_filter( 'woocommerce_payment_gateways', 'add_kwikpaisa_gateway' );
  
  function add_kwikpaisa_gateway( $methods ) {
    $methods[] = 'WC_Gateway_kwikpaisa';
    return $methods;
  }
}
